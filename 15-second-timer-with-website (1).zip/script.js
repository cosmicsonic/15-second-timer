const over_event = new Event("timer_over")
const start_event = new Event("timer_start")
const stop_event = new Event("timer_stop")
let timer_interval = null

let timer_amount = 0

function onStart() {
  document.dispatchEvent(start_event)
}

function onStop() {
  clearInterval(timer_interval)
  document.dispatchEvent(stop_event)
  timer_interval = null
}

function onReset() {
  timer_amount = 0
  onStop()
  seconds = document.getElementById("inc")
  seconds.innerText = timer_amount
}

function printHello() {
  timer_amount += 1

  if (timer_amount > 15) {
    timer_amount = 0
    document.dispatchEvent(over_event)
  }

  seconds = document.getElementById("inc")
  seconds.innerText = timer_amount
  
}

window.onload = function () {
  document.addEventListener("timer_start", function () {
    if (timer_interval == null) {
      timer_interval = setInterval(printHello, 1000)
      // status = document.getElementById("timer-status")
      // status.innerText = "status: "
    }
  })

  document.addEventListener("timer_over", function () {
    console.log("Timer is over!")
  })

  document.addEventListener("timer_stop", function () {
    // status = document.getElementById("timer-status")
    // status.innerText = "status: &#9940;"
  })
}